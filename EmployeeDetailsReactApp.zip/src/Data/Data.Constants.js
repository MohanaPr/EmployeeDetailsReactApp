
const constants = {
    GET_VALUEAPI:"GET_VALUEAPI",
}
export default constants;